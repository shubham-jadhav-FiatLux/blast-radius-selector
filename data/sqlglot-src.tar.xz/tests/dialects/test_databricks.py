from sqlglot import exp, transpile, parse_one, parse
from sqlglot.errors import ErrorLevel, ParseError, UnsupportedError
from tests.dialects.test_dialect import Validator


class TestDatabricks(Validator):
    dialect = "databricks"

    def test_unnest(self):
        self.validate_all(
            "SELECT b.name, t.id FROM a CROSS JOIN LATERAL EXPLODE(a.ids) AS t(id) "
            "JOIN b ON b.id = t.id",
            read={
                "trino": "SELECT b.name, t.id FROM a CROSS JOIN UNNEST(a.ids) AS t(id) "
                "JOIN b ON b.id = t.id",
            },
        )
        self.validate_all(
            "SELECT a.k, t.x FROM a LEFT JOIN LATERAL EXPLODE(a.arr) AS t(x) ON TRUE",
            read={"trino": "SELECT a.k, t.x FROM a LEFT JOIN UNNEST(a.arr) AS t(x) ON TRUE"},
        )
        self.validate_all(
            "SELECT s.x FROM a CROSS JOIN LATERAL EXPLODE(a.arrays) AS t(arr) "
            "CROSS JOIN LATERAL EXPLODE(t.arr) AS s(x)",
            read={
                "trino": "SELECT s.x FROM a CROSS JOIN UNNEST(a.arrays) AS t(arr) "
                "CROSS JOIN UNNEST(t.arr) AS s(x)",
            },
        )
        self.validate_all(
            "SELECT * FROM INLINE(ARRAYS_ZIP(ARRAY(1, 2), ARRAY(3))) AS t(x, y)",
            read={"trino": "SELECT * FROM UNNEST(ARRAY[1, 2], ARRAY[3]) AS t(x, y)"},
        )

    def test_unnest_with_ordinality(self):
        for join in ("CROSS JOIN", "LEFT JOIN"):
            on = " ON TRUE" if join == "LEFT JOIN" else ""
            with self.subTest(join=join):
                sql = f"SELECT t.* FROM a {join} UNNEST(a.arr) WITH ORDINALITY AS t(x, n){on}"
                self.validate_all(
                    f"SELECT t.* FROM a {join} LATERAL (SELECT * EXCEPT (pos), "
                    f"CAST(pos AS BIGINT) + 1 AS n FROM POSEXPLODE(a.arr)) AS t(x, n){on}",
                    read={"trino": sql, "presto": sql},
                )

        self.validate_all(
            "SELECT t.n, COUNT(*) FROM a CROSS JOIN LATERAL (SELECT * EXCEPT (pos), "
            "CAST(pos AS BIGINT) + 1 AS n FROM POSEXPLODE(a.arr)) AS t(x, n) "
            "JOIN b ON b.id = t.n WHERE t.n = 1 GROUP BY t.n HAVING t.n > 0 ORDER BY t.n NULLS LAST",
            read={
                "trino": "SELECT t.n, COUNT(*) FROM a CROSS JOIN UNNEST(a.arr) "
                "WITH ORDINALITY AS t(x, n) JOIN b ON b.id = t.n "
                "WHERE t.n = 1 GROUP BY t.n HAVING t.n > 0 ORDER BY t.n",
            },
        )
        self.validate_all(
            "SELECT n, (SELECT n FROM b) AS other_n FROM a CROSS JOIN LATERAL "
            "(SELECT * EXCEPT (pos), CAST(pos AS BIGINT) + 1 AS n FROM POSEXPLODE(a.arr)) AS t(x, n)",
            read={
                "trino": "SELECT n, (SELECT n FROM b) AS other_n FROM a "
                "CROSS JOIN UNNEST(a.arr) WITH ORDINALITY AS t(x, n)",
            },
        )
        self.validate_all(
            "SELECT * FROM a CROSS JOIN LATERAL (SELECT * EXCEPT (pos), "
            "CAST(pos AS BIGINT) + 1 AS n FROM POSEXPLODE(a.arr)) AS t(x, n)",
            read={
                "postgres": "SELECT * FROM a CROSS JOIN LATERAL UNNEST(a.arr) "
                "WITH ORDINALITY AS t(x, n)",
            },
        )
        self.validate_all(
            "SELECT * FROM (SELECT * EXCEPT (pos), CAST(pos AS BIGINT) + 1 AS n "
            "FROM POSEXPLODE(ARRAY(10, 20))) AS t(x, n)",
            read={"trino": "SELECT * FROM UNNEST(ARRAY[10, 20]) WITH ORDINALITY AS t(x, n)"},
        )
        self.validate_all(
            "SELECT * FROM (SELECT col.*, CAST(pos AS BIGINT) + 1 AS n "
            "FROM POSEXPLODE(ARRAYS_ZIP(ARRAY(1, 2), ARRAY(3)))) AS t(x, y, n)",
            read={
                "trino": "SELECT * FROM UNNEST(ARRAY[1, 2], ARRAY[3]) "
                "WITH ORDINALITY AS t(x, y, n)",
            },
        )
        self.validate_all(
            "SELECT * FROM (SELECT * EXCEPT (pos), CAST(pos AS BIGINT) + 1 AS n "
            "FROM POSEXPLODE(MAP_FROM_ARRAYS(ARRAY(1), ARRAY(10)))) AS t(k, v, n)",
            read={
                "trino": "SELECT * FROM UNNEST(MAP(ARRAY[1], ARRAY[10])) "
                "WITH ORDINALITY AS t(k, v, n)",
            },
        )
        self.validate_all(
            "SELECT * FROM (SELECT * EXCEPT (pos), CAST(pos AS BIGINT) + 1 AS ordinality "
            "FROM POSEXPLODE(ARRAY(10, 20)))",
            read={"trino": "SELECT * FROM UNNEST(ARRAY[10, 20]) WITH ORDINALITY"},
        )
        self.validate_all(
            "SELECT `t`.`n` FROM a CROSS JOIN LATERAL (SELECT * EXCEPT (pos), "
            "CAST(pos AS BIGINT) + 1 AS `n` FROM POSEXPLODE(a.arr)) AS `t`(`x`, `n`)",
            read={
                "trino": 'SELECT "t"."n" FROM a CROSS JOIN UNNEST(a.arr) '
                'WITH ORDINALITY AS "t"("x", "n")',
            },
        )

    def test_timestamp_without_time_zone(self):
        expression = self.parse_one("TIMESTAMP WITHOUT TIME ZONE", into=exp.DataType)
        self.assertEqual(expression.this, exp.DType.TIMESTAMPNTZ)

        self.validate_all(
            "CAST(x AS TIMESTAMP(6) WITHOUT TIME ZONE)",
            write={
                "databricks": "CAST(x AS TIMESTAMP_NTZ(6))",
                "duckdb": "CAST(x AS TIMESTAMP(6))",
            },
        )

    def test_timestamp_precision(self):
        for timestamp_type in ("TIMESTAMP", "TIMESTAMP_NTZ", "TIMESTAMP_LTZ"):
            for precision in range(6, 10):
                with self.subTest(timestamp_type=timestamp_type, precision=precision):
                    self.validate_identity(f"CREATE TABLE t (ts {timestamp_type}({precision}))")
                    self.validate_identity(
                        f"SELECT CAST('2026-08-18 14:30:45.123456789' AS {timestamp_type}({precision}))"
                    )

        self.validate_all(
            "CREATE TABLE t (ts TIMESTAMP(9))",
            write={
                "databricks": "CREATE TABLE t (ts TIMESTAMP(9))",
                "hive": "CREATE TABLE t (ts TIMESTAMP)",
                "spark": "CREATE TABLE t (ts TIMESTAMP)",
                "spark2": "CREATE TABLE t (ts TIMESTAMP)",
            },
        )

        # Databricks rejects a timestamp precision outside of 6 to 9, so any other
        # precision is dropped instead of being preserved
        for timestamp_type in ("TIMESTAMP", "TIMESTAMP_NTZ", "TIMESTAMP_LTZ"):
            for precision in list(range(6)) + [10]:
                with self.subTest(timestamp_type=timestamp_type, precision=precision):
                    self.validate_all(
                        f"SELECT CAST(x AS {timestamp_type})",
                        read={"databricks": f"SELECT CAST(x AS {timestamp_type}({precision}))"},
                    )

        self.validate_all(
            "SELECT CAST('2024-01-01 00:00:00' AS TIMESTAMP)",
            read={"trino": "SELECT TIMESTAMP '2024-01-01 00:00:00'"},
        )
        self.validate_all(
            "SELECT CAST(x AS TIMESTAMP)",
            read={
                "mysql": "SELECT CAST(x AS DATETIME(3))",
                "snowflake": "SELECT CAST(x AS TIMESTAMP(3))",
            },
        )
        self.validate_all(
            "SELECT CAST(x AS TIMESTAMP(6))",
            read={"mysql": "SELECT CAST(x AS DATETIME(6))"},
        )
        self.validate_all(
            "SELECT CAST(x AS TIMESTAMP)",
            read={"snowflake": "SELECT CAST(x AS TIMESTAMPTZ(3))"},
        )

    def test_match_recognize(self):
        sql = (
            "SELECT symbol, start_tstamp, end_tstamp, run_length FROM stock_ticker "
            "MATCH_RECOGNIZE (PARTITION BY symbol ORDER BY tstamp "
            "MEASURES FIRST(tstamp) AS start_tstamp, LAST(tstamp) AS end_tstamp, "
            "COUNT(*) AS run_length ONE ROW PER MATCH AFTER MATCH SKIP PAST LAST ROW "
            "PATTERN (strt up+) DEFINE up AS price > PREV(price))"
        )
        expression = self.validate_identity(f"{sql} AS T", f"{sql} T")
        self.assertIsInstance(expression.args["match"], exp.MatchRecognize)
        self.assertEqual(self.parse_one(expression.sql(self.dialect)), expression)

        for rows in ("", "ALL ROWS PER MATCH ", "ALL ROWS PER MATCH SHOW EMPTY MATCHES "):
            with self.subTest(rows=rows):
                self.validate_identity(
                    "SELECT * FROM stock_ticker MATCH_RECOGNIZE ("
                    "PARTITION BY symbol ORDER BY tstamp "
                    "MEASURES MATCH_NUMBER() AS match_no, CLASSIFIER() AS class, "
                    "LAST(down.tstamp) AS bottom_tstamp "
                    f"{rows}PATTERN (strt down+ up+) "
                    "DEFINE down AS price < PREV(price), up AS price > PREV(price))"
                )

    def test_insert_replace_using(self):
        self.validate_identity(
            "INSERT INTO target REPLACE USING (c1, c2) SELECT c1, c2 FROM source"
        )

    def test_databricks(self):
        self.validate_identity("CREATE TABLE foo (my_arr ARRAY<STRING COLLATE UTF8_BINARY>)")
        self.validate_identity("CREATE TABLE foo (m MAP<STRING, STRING COLLATE UTF8_BINARY>)")
        self.validate_identity("SELECT CAST('a' AS STRING COLLATE UTF8_BINARY)")
        self.validate_identity("SELECT COSH(1.5)")
        null_type = exp.DataType.build("VOID", dialect="databricks")
        self.assertEqual(null_type.sql(), "NULL")
        self.assertEqual(null_type.sql("databricks"), "VOID")

        self.validate_identity("DESCRIBE EXTENDED staging.onetrade_startb AS JSON")
        self.validate_identity("SELECT BITMAP_BIT_POSITION(10)")
        self.validate_identity("SELECT BITMAP_BUCKET_NUMBER(32769)")
        self.validate_identity("SELECT BITMAP_CONSTRUCT_AGG(value)")
        self.validate_identity("SELECT EXP(1)")
        self.validate_identity("SELECT MODE(category)")
        self.validate_identity("SELECT MODE(price, TRUE) AS deterministic_mode FROM products")
        self.validate_identity("REGEXP_LIKE(x, y)")
        self.validate_identity("SELECT CAST(NULL AS VOID)")
        self.validate_identity("SELECT void FROM t")
        self.validate_identity("SELECT * FROM stream")
        self.validate_identity("SELECT * FROM STREAM t")
        self.validate_identity("SELECT t.current_time FROM t")
        self.validate_identity("ALTER TABLE labels ADD COLUMN label_score FLOAT")
        self.validate_identity("DESCRIBE HISTORY a.b")
        self.validate_identity("DESCRIBE history.tbl")
        self.validate_identity("CREATE TABLE t (a STRUCT<c: MAP<STRING, STRING>>)")
        self.validate_identity("CREATE TABLE t (c STRUCT<interval: DOUBLE COMMENT 'aaa'>)")
        self.validate_identity("CREATE TABLE t (c STRING COMMENT 'Hello World')")
        self.validate_identity("CREATE TABLE my_table TBLPROPERTIES (a.b=15)")
        self.validate_identity("CREATE TABLE my_table TBLPROPERTIES ('a.b'=15)")
        self.validate_identity("CREATE TABLE table1 CLUSTER BY AUTO")
        self.validate_identity(
            "CREATE TABLE t (customer_id INT NOT NULL, ts TIMESTAMP NOT NULL, CONSTRAINT customer_features_pk PRIMARY KEY (customer_id, ts TIMESERIES))"
        )
        self.validate_all(
            "CREATE TABLE t (a INT, b TIMESTAMP, PRIMARY KEY (a, b TIMESERIES))",
            write={
                "databricks": "CREATE TABLE t (a INT, b TIMESTAMP, PRIMARY KEY (a, b TIMESERIES))",
                "duckdb": "CREATE TABLE t (a INT, b TIMESTAMPTZ, PRIMARY KEY (a, b))",
            },
        )
        self.validate_identity("ALTER TABLE t CLUSTER BY NONE")
        self.validate_identity("CREATE TABLE t CLUSTER BY (col1)")
        self.validate_identity("CREATE TABLE t CLUSTER BY (col1, col2)")
        self.validate_identity("SELECT col1 FROM t CLUSTER BY col1")
        self.validate_identity("SELECT col1, col2 FROM t CLUSTER BY col1, col2")
        self.validate_identity("SELECT CAST('11 23:4:0' AS INTERVAL DAY TO HOUR)")
        self.validate_identity("SELECT CAST('11 23:4:0' AS INTERVAL DAY TO MINUTE)")
        self.validate_identity("SELECT CAST('11 23:4:0' AS INTERVAL DAY TO SECOND)")
        self.validate_identity("SELECT CAST('23:00:00' AS INTERVAL HOUR TO MINUTE)")
        self.validate_identity("SELECT CAST('23:00:00' AS INTERVAL HOUR TO SECOND)")
        self.validate_identity("SELECT CAST('23:00:00' AS INTERVAL MINUTE TO SECOND)")
        self.validate_identity("CREATE TABLE target SHALLOW CLONE source")
        self.validate_identity("INSERT INTO a REPLACE WHERE cond VALUES (1), (2)")
        self.validate_identity("CREATE FUNCTION a.b(x INT) RETURNS INT RETURN x + 1")
        self.validate_identity(
            "CREATE FUNCTION f(col STRING) RETURNS STRING DETERMINISTIC RETURN col"
        )
        self.validate_identity(
            "CREATE FUNCTION f(col STRING) RETURNS STRING NOT DETERMINISTIC RETURN col"
        )
        self.validate_identity("CREATE FUNCTION a AS b")
        self.validate_identity("SELECT ${x} FROM ${y} WHERE ${z} > 1")
        self.validate_identity("CREATE TABLE foo (x DATE GENERATED ALWAYS AS (CAST(y AS DATE)))")
        self.validate_identity("TRUNCATE TABLE t1 PARTITION(age = 10, name = 'test', address)")
        self.validate_identity("SELECT PARSE_JSON('{}')")
        self.validate_identity("SELECT RANDSTR(123)")
        self.validate_identity("SELECT RANDSTR(123, 456)")

        self.validate_identity("PARSE_URL('https://example.com/path')")
        self.validate_identity("PARSE_URL('https://example.com/path', 'HOST')")
        self.validate_identity("PARSE_URL('https://example.com/path', 'QUERY', 'param')")
        self.validate_identity(
            "CREATE TABLE IF NOT EXISTS db.table (a TIMESTAMP, b BOOLEAN GENERATED ALWAYS AS (NOT a IS NULL)) USING DELTA"
        )
        self.validate_identity(
            "SELECT * FROM sales UNPIVOT INCLUDE NULLS (sales FOR quarter IN (q1 AS `Jan-Mar`))"
        )
        self.validate_identity(
            "SELECT * FROM sales UNPIVOT EXCLUDE NULLS (sales FOR quarter IN (q1 AS `Jan-Mar`))"
        )
        self.validate_identity(
            "CREATE FUNCTION add_one(x INT) RETURNS INT LANGUAGE PYTHON AS $$def add_one(x):\n  return x+1$$"
        )
        self.validate_identity(
            "CREATE FUNCTION add_one(x INT) RETURNS INT LANGUAGE PYTHON AS $FOO$def add_one(x):\n  return x+1$FOO$"
        )
        self.validate_identity(
            "TRUNCATE TABLE t1 PARTITION(age = 10, name = 'test', city LIKE 'LA')"
        )
        self.validate_identity(
            "COPY INTO target FROM `s3://link` FILEFORMAT = AVRO VALIDATE = ALL FILES = ('file1', 'file2') FORMAT_OPTIONS ('opt1'='true', 'opt2'='test') COPY_OPTIONS ('mergeSchema'='true')"
        )
        self.validate_identity(
            "SELECT * FROM t1, t2",
            "SELECT * FROM t1 CROSS JOIN t2",
        )
        self.validate_identity(
            "SELECT TIMESTAMP '2025-04-29 18.47.18'::DATE",
            "SELECT CAST(CAST('2025-04-29 18.47.18' AS DATE) AS TIMESTAMP)",
        )
        self.validate_identity(
            "SELECT DATE_FORMAT(CAST(FROM_UTC_TIMESTAMP(foo, 'America/Los_Angeles') AS TIMESTAMP), 'yyyy-MM-dd HH:mm:ss') AS foo FROM t",
            "SELECT DATE_FORMAT(CAST(FROM_UTC_TIMESTAMP(CAST(foo AS TIMESTAMP), 'America/Los_Angeles') AS TIMESTAMP), 'yyyy-MM-dd HH:mm:ss') AS foo FROM t",
        )
        self.validate_identity(
            "DATE_DIFF(day, created_at, current_date())",
            "DATEDIFF(DAY, created_at, CURRENT_DATE)",
        ).args["unit"].assert_is(exp.Var)
        self.validate_identity(
            r'SELECT r"\\foo.bar\"',
            r"SELECT '\\\\foo.bar\\'",
        )
        self.validate_identity(
            "FROM_UTC_TIMESTAMP(x::TIMESTAMP, tz)",
            "FROM_UTC_TIMESTAMP(CAST(x AS TIMESTAMP), tz)",
        )

        self.validate_identity("SELECT SUBSTRING_INDEX(str, delim, count)")
        self.validate_identity("BITMAP_OR_AGG(x)")

        self.validate_all(
            "SELECT SUBSTRING_INDEX('a.b.c.d', '.', 2)",
            write={
                "databricks": "SELECT SUBSTRING_INDEX('a.b.c.d', '.', 2)",
                "spark": "SELECT SUBSTRING_INDEX('a.b.c.d', '.', 2)",
                "mysql": "SELECT SUBSTRING_INDEX('a.b.c.d', '.', 2)",
            },
        )
        self.validate_identity(
            "SELECT SUBSTR('Spark' FROM 5 FOR 1)", "SELECT SUBSTRING('Spark', 5, 1)"
        )
        self.validate_identity("SELECT SUBSTR('Spark SQL', 5)", "SELECT SUBSTRING('Spark SQL', 5)")
        self.validate_identity(
            "SELECT SUBSTR(ENCODE('Spark SQL', 'utf-8'), 5)",
            "SELECT SUBSTRING(ENCODE('Spark SQL', 'utf-8'), 5)",
        )
        self.validate_all(
            "SELECT TYPEOF(1)",
            read={
                "databricks": "SELECT TYPEOF(1)",
                "snowflake": "SELECT TYPEOF(1)",
                "hive": "SELECT TYPEOF(1)",
                "clickhouse": "SELECT toTypeName(1)",
            },
            write={
                "clickhouse": "SELECT toTypeName(1)",
            },
        )

        self.validate_all(
            "SELECT c1:item[1].price",
            write={
                "databricks": "SELECT c1:item[1].price",
                "spark": "SELECT GET_JSON_OBJECT(c1, '$.item[1].price')",
            },
        )

        self.validate_all(
            "SELECT GET_JSON_OBJECT(c1, '$.item[1].price')",
            read={
                "spark": "SELECT GET_JSON_OBJECT(c1, '$.item[1].price')",
            },
            write={
                "databricks": "SELECT GET_JSON_OBJECT(c1, '$.item[1].price')",
                "spark": "SELECT GET_JSON_OBJECT(c1, '$.item[1].price')",
            },
        )
        self.validate_all(
            "CREATE TABLE foo (x INT GENERATED ALWAYS AS (YEAR(y)))",
            write={
                "databricks": "CREATE TABLE foo (x INT GENERATED ALWAYS AS (YEAR(y)))",
                "tsql": "CREATE TABLE foo (x AS YEAR(y))",
            },
        )
        self.validate_all(
            "CREATE TABLE t1 AS (SELECT c FROM t2)",
            read={
                "teradata": "CREATE TABLE t1 AS (SELECT c FROM t2) WITH DATA",
            },
        )
        self.validate_all(
            "SELECT X'1A2B'",
            read={
                "spark2": "SELECT X'1A2B'",
                "spark": "SELECT X'1A2B'",
                "databricks": "SELECT x'1A2B'",
            },
            write={
                "spark2": "SELECT X'1A2B'",
                "spark": "SELECT X'1A2B'",
                "databricks": "SELECT X'1A2B'",
            },
        )

        with self.assertRaises(ParseError):
            transpile(
                "CREATE FUNCTION add_one(x INT) RETURNS INT LANGUAGE PYTHON AS $foo$def add_one(x):\n  return x+1$$",
                read="databricks",
            )

        with self.assertRaises(ParseError):
            transpile(
                "CREATE FUNCTION add_one(x INT) RETURNS INT LANGUAGE PYTHON AS $foo bar$def add_one(x):\n  return x+1$foo bar$",
                read="databricks",
            )

        self.validate_all(
            "CREATE OR REPLACE FUNCTION func(a BIGINT, b BIGINT) RETURNS TABLE (a INT) RETURN SELECT a",
            write={
                "databricks": "CREATE OR REPLACE FUNCTION func(a BIGINT, b BIGINT) RETURNS TABLE (a INT) RETURN SELECT a",
                "duckdb": "CREATE OR REPLACE FUNCTION func(a BIGINT, b BIGINT) AS TABLE SELECT a",
            },
        )

        self.validate_all(
            "CREATE OR REPLACE FUNCTION func(a BIGINT, b BIGINT) RETURNS BIGINT RETURN a",
            write={
                "databricks": "CREATE OR REPLACE FUNCTION func(a BIGINT, b BIGINT) RETURNS BIGINT RETURN a",
                "duckdb": "CREATE OR REPLACE FUNCTION func(a BIGINT, b BIGINT) AS a",
            },
        )

        self.validate_all(
            "SELECT ANY(col) FROM VALUES (TRUE), (FALSE) AS tab(col)",
            read={
                "databricks": "SELECT ANY(col) FROM VALUES (TRUE), (FALSE) AS tab(col)",
                "spark": "SELECT ANY(col) FROM VALUES (TRUE), (FALSE) AS tab(col)",
            },
            write={
                "spark": "SELECT ANY(col) FROM VALUES (TRUE), (FALSE) AS tab(col)",
            },
        )

        for option in ("", " (foo)", " MATCH FULL", " NOT ENFORCED"):
            with self.subTest(f"Databricks foreign key REFERENCES option: {option}."):
                self.validate_identity(
                    f"CREATE TABLE t1 (foo BIGINT NOT NULL CONSTRAINT foo_c FOREIGN KEY REFERENCES t2{option})"
                )
        self.validate_identity(
            "SELECT test, LISTAGG(email, '') AS Email FROM organizations GROUP BY test",
        )

        self.validate_identity(
            "WITH t AS (VALUES ('foo_val') AS t(foo1)) SELECT foo1 FROM t",
            "WITH t AS (SELECT * FROM VALUES ('foo_val') AS t(foo1)) SELECT foo1 FROM t",
        )
        self.validate_identity("NTILE() OVER (ORDER BY 1)")
        self.validate_identity("CURRENT_VERSION()")
        self.validate_all(
            "UNIFORM(1, 10, 5)",
            write={
                "snowflake": "UNIFORM(1, 10, RANDOM(5))",
                "databricks": "UNIFORM(1, 10, 5)",
                "duckdb": "CAST(FLOOR(1 + (ABS(HASH(5)) % 1000000) / 1000000.0 * (10 - 1 + 1)) AS BIGINT)",
            },
        )
        self.validate_all(
            "UNIFORM(1, 10)",
            write={
                "databricks": "UNIFORM(1, 10)",
                "snowflake": "UNIFORM(1, 10, RANDOM())",
                "duckdb": "CAST(FLOOR(1 + RANDOM() * (10 - 1 + 1)) AS BIGINT)",
            },
        )
        self.validate_identity("SELECT ELT(2, 'foo', 'bar', 'baz') AS Result")
        self.validate_identity("GETDATE()", "CURRENT_TIMESTAMP()")
        self.validate_identity("NOW()", "CURRENT_TIMESTAMP()")
        self.validate_identity("CURRENT_TIMEZONE()")
        self.validate_identity("CURDATE()", "CURRENT_DATE")
        self.validate_identity("CURDATE", "CURRENT_DATE")
        self.validate_identity("SELECT MAKE_INTERVAL(100, 11, 12, 13, 14, 14, 15)")
        self.validate_identity("SELECT name, GROUPING_ID() FROM customer GROUP BY ROLLUP (name)")
        self.validate_identity("BIT_GET(11, 0)", "GETBIT(11, 0)")
        self.validate_identity("SELECT CURDATE()", "SELECT CURRENT_DATE")
        self.validate_identity(
            "CREATE TABLE tbl (id BIGINT NOT NULL GENERATED BY DEFAULT AS IDENTITY (START WITH 1 INCREMENT BY 1))"
        )
        self.validate_identity(
            "CREATE TABLE tbl (id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1))"
        )

        self.validate_identity(
            """WITH t AS (SELECT '{"x-y": "z"}' AS c) SELECT get_json_object(c, '$.x-y') FROM t""",
            """WITH t AS (SELECT '{"x-y": "z"}' AS c) SELECT GET_JSON_OBJECT(c, '$["x-y"]') FROM t""",
        ).selects[0].expression.assert_is(exp.JSONPath)

        self.validate_identity("INSERT INTO t REPLACE WHERE a = 1 SELECT * FROM src")
        self.validate_identity("INSERT INTO t REPLACE WHERE a = 2 (SELECT * FROM src)")
        self.validate_identity(
            "WITH s AS (SELECT * FROM src) INSERT INTO t REPLACE WHERE a = 1 SELECT * FROM s"
        )
        self.validate_identity(
            "WITH s AS (SELECT * FROM src) INSERT INTO t REPLACE USING (a) SELECT * FROM s"
        )

    # https://docs.databricks.com/sql/language-manual/functions/colonsign.html
    def test_json(self):
        self.validate_identity("SELECT c1:price, c1:price.foo, c1:price.bar[1]")
        self.validate_identity("SELECT TRY_CAST(c1:price AS ARRAY<VARIANT>)")
        self.validate_identity("""SELECT TRY_CAST(c1:["foo bar"]["baz qux"] AS ARRAY<VARIANT>)""")
        self.validate_identity(
            """SELECT c1:item[1].price FROM VALUES ('{ "item": [ { "model" : "basic", "price" : 6.12 }, { "model" : "medium", "price" : 9.24 } ] }') AS T(c1)"""
        )
        self.validate_identity(
            """SELECT c1:item[*].price FROM VALUES ('{ "item": [ { "model" : "basic", "price" : 6.12 }, { "model" : "medium", "price" : 9.24 } ] }') AS T(c1)"""
        )
        self.validate_identity(
            """SELECT FROM_JSON(c1:item[*].price, 'ARRAY<DOUBLE>')[0] FROM VALUES ('{ "item": [ { "model" : "basic", "price" : 6.12 }, { "model" : "medium", "price" : 9.24 } ] }') AS T(c1)"""
        )
        self.validate_identity(
            """SELECT INLINE(FROM_JSON(c1:item[*], 'ARRAY<STRUCT<model STRING, price DOUBLE>>')) FROM VALUES ('{ "item": [ { "model" : "basic", "price" : 6.12 }, { "model" : "medium", "price" : 9.24 } ] }') AS T(c1)"""
        )
        self.validate_identity(
            """SELECT c1:['price'] FROM VALUES ('{ "price": 5 }') AS T(c1)""",
            """SELECT c1:["price"] FROM VALUES ('{ "price": 5 }') AS T(c1)""",
        )
        self.validate_identity(
            """SELECT GET_JSON_OBJECT(c1, '$.price') FROM VALUES ('{ "price": 5 }') AS T(c1)"""
        )
        self.validate_identity("SELECT GET_JSON_OBJECT(col, path_col)")
        self.validate_identity("SELECT GET_JSON_OBJECT(col, CONCAT('$.', field_name))")
        self.validate_identity("SELECT GET_JSON_OBJECT(GET_JSON_OBJECT(col, '$[0]'), '$.a')")
        self.validate_identity(
            """SELECT raw:`zip code`, raw:`fb:testid`, raw:store['bicycle'], raw:store["zip code"]""",
            """SELECT raw:["zip code"], raw:["fb:testid"], raw:store["bicycle"], raw:store["zip code"]""",
        )
        self.validate_all(
            "SELECT col:`fr'uit`",
            write={
                "databricks": """SELECT col:["fr'uit"]""",
                "postgres": "SELECT JSON_EXTRACT_PATH(col, 'fr''uit')",
            },
        )

    def test_datediff(self):
        self.validate_all(
            "SELECT DATEDIFF(year, 'start', 'end')",
            write={
                "tsql": "SELECT DATEDIFF(YEAR, 'start', 'end')",
                "databricks": "SELECT DATEDIFF(YEAR, 'start', 'end')",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(microsecond, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(MICROSECOND, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(epoch FROM CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP)) * 1000000 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(millisecond, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(MILLISECOND, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(epoch FROM CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP)) * 1000 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(second, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(SECOND, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(epoch FROM CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP)) AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(minute, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(MINUTE, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(epoch FROM CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP)) / 60 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(hour, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(HOUR, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(epoch FROM CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP)) / 3600 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(day, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(DAY, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(epoch FROM CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP)) / 86400 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(week, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(WEEK, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(days FROM (CAST('end' AS TIMESTAMP) - CAST('start' AS TIMESTAMP))) / 7 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(month, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(MONTH, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(year FROM AGE(CAST('end' AS TIMESTAMP), CAST('start' AS TIMESTAMP))) * 12 + EXTRACT(month FROM AGE(CAST('end' AS TIMESTAMP), CAST('start' AS TIMESTAMP))) AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(quarter, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(QUARTER, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(year FROM AGE(CAST('end' AS TIMESTAMP), CAST('start' AS TIMESTAMP))) * 4 + EXTRACT(month FROM AGE(CAST('end' AS TIMESTAMP), CAST('start' AS TIMESTAMP))) / 3 AS BIGINT)",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF(year, 'start', 'end')",
            write={
                "databricks": "SELECT DATEDIFF(YEAR, 'start', 'end')",
                "postgres": "SELECT CAST(EXTRACT(year FROM AGE(CAST('end' AS TIMESTAMP), CAST('start' AS TIMESTAMP))) AS BIGINT)",
            },
        )

    def test_add_date(self):
        self.validate_all(
            "SELECT DATEADD(year, 1, '2020-01-01')",
            write={
                "tsql": "SELECT DATEADD(YEAR, 1, '2020-01-01')",
                "databricks": "SELECT DATE_ADD(YEAR, 1, '2020-01-01')",
            },
        )
        self.validate_all(
            "SELECT DATEDIFF('end', 'start')",
            write={"databricks": "SELECT DATEDIFF(DAY, 'start', 'end')"},
        )
        self.validate_all(
            "SELECT DATE_ADD('2020-01-01', 1)",
            write={
                "tsql": "SELECT DATEADD(DAY, 1, CAST(CAST('2020-01-01' AS DATETIME2) AS DATE))",
                "databricks": "SELECT DATE_ADD('2020-01-01', 1)",
            },
        )
        self.validate_identity("SELECT DATE_ADD(MONTH, 1, '2020-01-01')")
        self.validate_identity(
            "SELECT DATEADD(e, 24) FROM t",
            "SELECT DATE_ADD(e, 24) FROM t",
        )

    def test_without_as(self):
        self.validate_all(
            "CREATE TABLE x (SELECT 1)",
            write={
                "databricks": "CREATE TABLE x AS (SELECT 1)",
            },
        )

        self.validate_all(
            "WITH x (select 1) SELECT * FROM x",
            write={
                "databricks": "WITH x AS (SELECT 1) SELECT * FROM x",
            },
        )

    def test_streaming_tables(self):
        self.validate_identity(
            "CREATE STREAMING TABLE raw_data AS SELECT * FROM STREAM READ_FILES('abfss://container@storageAccount.dfs.core.windows.net/base/path')"
        )
        self.validate_identity(
            "CREATE OR REFRESH STREAMING TABLE csv_data (id INT, ts TIMESTAMP, event STRING) AS SELECT * FROM STREAM READ_FILES('s3://bucket/path', format => 'csv', schema => 'id int, ts timestamp, event string')"
        )

    def test_grant(self):
        self.validate_identity("GRANT CREATE ON SCHEMA my_schema TO `alf@melmak.et`")
        self.validate_identity("GRANT SELECT ON TABLE sample_data TO `alf@melmak.et`")
        self.validate_identity("GRANT ALL PRIVILEGES ON TABLE forecasts TO finance")
        self.validate_identity("GRANT SELECT ON TABLE t TO `fab9e00e-ca35-11ec-9d64-0242ac120002`")

    def test_revoke(self):
        self.validate_identity("REVOKE CREATE ON SCHEMA my_schema FROM `alf@melmak.et`")
        self.validate_identity("REVOKE SELECT ON TABLE sample_data FROM `alf@melmak.et`")
        self.validate_identity("REVOKE ALL PRIVILEGES ON TABLE forecasts FROM finance")
        self.validate_identity(
            "REVOKE SELECT ON TABLE t FROM `fab9e00e-ca35-11ec-9d64-0242ac120002`"
        )

    def test_optimize(self):
        for sql in (
            "OPTIMIZE t",
            "OPTIMIZE db.t",
            "OPTIMIZE catalog.db.t",
            "OPTIMIZE `cat.name`.`some schema`.`a``b`",
            "OPTIMIZE `DOUBLE PRECISION`",
            "OPTIMIZE 123t",
            "OPTIMIZE vacuum.t",
            "OPTIMIZE optimize.t",
        ):
            with self.subTest(sql=sql):
                tree = self.validate_identity(sql)
                self.assertIsInstance(tree, exp.Optimize)
                self.assertIsInstance(tree.this, exp.Table)
                self.assertEqual(list(tree.find_all(exp.Table)), [tree.this])
                for part in tree.this.parts:
                    self.assertEqual(
                        sql[part.meta["start"] : part.meta["end"] + 1],
                        part.sql(dialect="databricks"),
                    )

        tree = self.validate_identity("optimize db.t", "OPTIMIZE db.t")
        self.assertEqual(exp.Expr.load(tree.dump()), tree)
        self.assertEqual(tree, self.parse_one(tree.sql(dialect="databricks")))
        for sql in ("SELECT optimize FROM optimize", "SELECT 1 AS optimize"):
            self.validate_identity(sql)
        self.validate_identity("SELECT 1 optimize", "SELECT 1 AS optimize")
        self.validate_identity("SELECT * FROM t optimize", "SELECT * FROM t AS optimize")
        self.validate_identity("SELECT OPTIMIZE(1)")
        table = self.parse_one("OPTIMIZE\ncatalog.t").this
        self.assertEqual((table.this.meta["line"], table.this.meta["col"]), (2, 9))

        statements = parse("OPTIMIZE `a;b`; OPTIMIZE t FULL; SELECT 1", read="databricks")
        self.assertEqual(
            [type(tree) for tree in statements], [exp.Optimize, exp.Command, exp.Select]
        )
        for dialect in ("hive", "spark", "snowflake"):
            with self.subTest(dialect=dialect):
                self.assertIsInstance(parse_one("OPTIMIZE t", read=dialect), exp.Command)
                with self.assertRaises(UnsupportedError):
                    tree.sql(dialect=dialect, unsupported_level=ErrorLevel.RAISE)

    def test_optimize_comments(self):
        for sql in (
            "/* comment */ OPTIMIZE db.t",
            "OPTIMIZE /* comment */ db.t",
            "OPTIMIZE db /* comment */ .t",
            "OPTIMIZE db. /* comment */ t",
            "OPTIMIZE db. -- comment\nt",
            "OPTIMIZE db.t /* comment */",
            "OPTIMIZE db.t -- comment\n",
        ):
            with self.subTest(sql=sql):
                tree = self.validate_identity(sql, "OPTIMIZE db.t /* comment */")
                self.assertIsInstance(tree, exp.Optimize)
                self.assertIsInstance(tree.this, exp.Table)
        tree = self.validate_identity(
            "OPTIMIZE catalog. /* first */ db. /* second */ t",
            "OPTIMIZE catalog.db.t /* first */ /* second */",
        )
        self.assertEqual([comment.strip() for comment in tree.this.comments], ["first", "second"])

    def test_optimize_comment_order(self):
        self.validate_identity(
            "/* first */ OPTIMIZE db. /* second */ t /* third */",
            "OPTIMIZE db.t /* second */ /* third */ /* first */",
        )
        tree = self.validate_identity(
            "OPTIMIZE CaT. /* sqlglot.meta case_sensitive=true */ "
            "Db /* sqlglot.meta case_sensitive=false */",
            "OPTIMIZE CaT.Db /* sqlglot.meta case_sensitive=true */ "
            "/* sqlglot.meta case_sensitive=false */",
        )
        self.assertFalse(tree.this.meta["case_sensitive"])

    def test_optimize_fallback(self):
        for sql in (
            "OPTIMIZE t FULL",
            "OPTIMIZE t WHERE partition_id = 1",
            "OPTIMIZE t ZORDER BY (id)",
            "OPTIMIZE t WHERE partition_id = 1 ZORDER BY (id)",
            "OPTIMIZE a.b.c.d",
            "OPTIMIZE t.",
            "OPTIMIZE 'not_a_table'",
            "OPTIMIZE 1e3",
            "OPTIMIZE DOUBLE PRECISION",
            "OPTIMIZE DOUBLE\tPRECISION",
            "OPTIMIZE t.ADD FILE",
            "OPTIMIZE f(" + "(" * 80 + "1" + ")" * 80 + ")",
        ):
            with self.subTest(sql=sql):
                self.assertIsInstance(
                    self.validate_identity(sql, check_command_warning=True), exp.Command
                )
        for sql in ("OPTIMIZE t FULL /* trailing */", "OPTIMIZE t FULL -- trailing\n"):
            tree = self.validate_identity(sql, "/* trailing */ OPTIMIZE t FULL")
            self.assertIsInstance(tree, exp.Command)
            self.assertEqual([comment.strip() for comment in tree.comments], ["trailing"])

    def test_optimize_parser_limits(self):
        with self.assertRaises(ParseError):
            self.parse_one("OPTIMIZE t", max_nodes=1)
        self.assertIsInstance(self.parse_one("OPTIMIZE t", max_nodes=2), exp.Optimize)
        with self.assertRaises(ParseError):
            self.parse_one("OPTIMIZE t FULL", max_nodes=0)

    def test_analyze(self):
        self.validate_identity("ANALYZE TABLE tbl COMPUTE DELTA STATISTICS NOSCAN")
        self.validate_identity("ANALYZE TABLE tbl COMPUTE DELTA STATISTICS FOR ALL COLUMNS")
        self.validate_identity("ANALYZE TABLE tbl COMPUTE DELTA STATISTICS FOR COLUMNS foo, bar")
        self.validate_identity("ANALYZE TABLE ctlg.db.tbl COMPUTE DELTA STATISTICS NOSCAN")
        self.validate_identity("ANALYZE TABLES COMPUTE STATISTICS NOSCAN")
        self.validate_identity("ANALYZE TABLES FROM db COMPUTE STATISTICS")
        self.validate_identity("ANALYZE TABLES IN db COMPUTE STATISTICS")
        self.validate_identity(
            "ANALYZE TABLE ctlg.db.tbl PARTITION(foo = 'foo', bar = 'bar') COMPUTE STATISTICS NOSCAN"
        )

    def test_udf_environment_property(self):
        self.validate_identity(
            """CREATE FUNCTION a() ENVIRONMENT (dependencies = '["foo1==1", "foo2==2"]', environment_version = 'None')"""
        )

    def test_udf_handler_property(self):
        self.validate_identity("""CREATE FUNCTION a() HANDLER 'handler_function'""")

    def test_udf_parameter_style_property(self):
        self.validate_identity("""CREATE FUNCTION a() PARAMETER STYLE PANDAS""")

    def test_to_char_is_numeric_transpile_to_cast(self):
        # The input SQL simulates a TO_CHAR with is_numeric flag set (from dremio dialect)
        sql = "SELECT TO_CHAR(12345, '#')"
        expression = parse_one(sql, read="dremio")

        to_char_exp = expression.find(exp.ToChar)
        assert to_char_exp is not None
        assert to_char_exp.args.get("is_numeric") is True

        result = transpile(sql, read="dremio", write="databricks")[0]
        assert "CAST(12345 AS STRING)" in result

    def test_qdcolon(self):
        self.validate_identity("SELECT '20'?::INTEGER", "SELECT TRY_CAST('20' AS INT)")

    def test_overlay(self):
        self.validate_identity(
            "SELECT OVERLAY('Spark SQL', 'ANSI ', 7, 0)",
            "SELECT OVERLAY('Spark SQL' PLACING 'ANSI ' FROM 7 FOR 0)",
        )
        self.validate_identity(
            "SELECT OVERLAY('Spark SQL' PLACING 'CORE' FROM 7)",
        )
        self.validate_identity(
            "SELECT OVERLAY(ENCODE('Spark SQL', 'utf-8') PLACING ENCODE('_', 'utf-8') FROM 6)",
        )
        self.validate_identity(
            "SELECT OVERLAY('Spark SQL' PLACING 'ANSI ' FROM 7 FOR 0)",
        )

    def test_set_variable(self):
        self.validate_identity("SET VAR v = 5", "SET VARIABLE v = 5")
        self.validate_identity("SET VARIABLE v = 5")
        self.validate_identity("SET VARIABLE v1 = 1, v2 = '2'")
        self.validate_identity("SET VARIABLE (v1, v2) = (SELECT 1, 2)")
        self.validate_identity("SET VARIABLE v = (SELECT MAX(c1) FROM VALUES (1), (2) AS T(c1))")
        self.validate_identity("SET VARIABLE v = DEFAULT")

    def test_iff(self):
        # IFF is a synonym for IF in Databricks; it normalizes to IF on output
        self.validate_all(
            "SELECT IF(x > 0, 'positive', 'non-positive')",
            read={"databricks": "SELECT IFF(x > 0, 'positive', 'non-positive')"},
            write={
                "databricks": "SELECT IF(x > 0, 'positive', 'non-positive')",
                "snowflake": "SELECT IFF(x > 0, 'positive', 'non-positive')",
            },
        )

    def test_try_divide(self):
        self.validate_all(
            "SELECT TRY_DIVIDE(a, b)",
            read={"databricks": "SELECT TRY_DIVIDE(a, b)"},
            write={
                "databricks": "SELECT TRY_DIVIDE(a, b)",
                "snowflake": "SELECT IFF(b <> 0, a / b, NULL)",
                "duckdb": "SELECT CASE WHEN b <> 0 THEN a / b ELSE NULL END",
                "spark": "SELECT TRY_DIVIDE(a, b)",
            },
        )

    def test_declare(self):
        self.validate_identity("DECLARE VAR x INT", "DECLARE x INT")
        self.validate_identity("DECLARE x INT")
        self.validate_identity("DECLARE VARIABLE myvar INT DEFAULT 1", "DECLARE myvar INT = 1")
        self.validate_identity("DECLARE x, y, z INT DEFAULT 1", "DECLARE x, y, z INT = 1")
        self.validate_identity("DECLARE x INT = 1")
        self.validate_identity("DECLARE OR REPLACE x INT = 1")
